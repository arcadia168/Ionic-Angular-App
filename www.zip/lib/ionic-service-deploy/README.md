ionic-service-deploy
====================

App deploy service for Ionic. Official docs: http://docs.ionic.io/v1.0/docs/deploy-updating-apps
