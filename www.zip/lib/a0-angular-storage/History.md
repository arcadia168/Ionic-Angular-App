
0.0.6 / 2014-10-08
==================

  * Added dist files I forgot

0.0.5 / 2014-10-08
==================

  * Added namespaced stores

0.0.4 / 2014-10-07
==================

  * New dist files

0.0.3 / 2014-10-07
==================

  * Added fixes asked by @matjaz.
  * Update README.md
  * Update bower.json
  * Update README.md
  * Update README.md
  * 0.0.2
  * Added dist ngAnnotate
