ionic-service-analytics
=======================

Ionic Analytics Service. See the official docs here: http://docs.ionic.io/v1.0/docs/analytics-from-scratch
